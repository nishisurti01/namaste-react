import { createContext } from "react";

const Usercontext = createContext({
    loggedinUser : "demo"
})

export default Usercontext;