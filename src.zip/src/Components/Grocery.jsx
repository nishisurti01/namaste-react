const Grocery = () => {
  return (
    <div>
      <h1>Grocery Stores which will have many components</h1>
    </div>
  );
};

export default Grocery;
