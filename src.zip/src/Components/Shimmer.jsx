const Shimmer = () => {
  return (
    <div className="shimmer-container">
      <div className="shimmer-card">Cards</div>
      <div className="shimmer-card">Cards</div>
      <div className="shimmer-card">Cards</div>
    </div>
  );
};

export default Shimmer;
