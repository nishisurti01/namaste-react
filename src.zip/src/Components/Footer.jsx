const Footer = () => {
    return (
      <div className="footer">
        {" "}
        <h3>© 2024 Nishi Surti</h3>
      </div>
    );
  };

  export default Footer;